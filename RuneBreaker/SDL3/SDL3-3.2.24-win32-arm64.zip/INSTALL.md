
# Using this package

This package contains SDL3 built for arm64 Windows.

To use this package, simply replace an existing 64-bit ARM SDL3.dll with the one included here.

# Development packages

If you're looking for packages with headers and libraries, you can download one of these:
-  SDL3-devel-3.2.24-VC.zip, for development using Visual Studio
-  SDL3-devel-3.2.24-mingw.zip, for development using mingw-w64

